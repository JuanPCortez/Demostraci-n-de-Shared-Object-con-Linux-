#include <stdio.h>
#include "holaprintlibrary.h"

int main(){
  puts("Prueba con shared object\n");
  print("Hola mundo con shared object\n");
  return 0;
}